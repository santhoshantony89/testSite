$(document).ready(function () {
    var links = [
        {
            "bgcolor":"#00a17c",
            "icon":"+"
        },
        {
            "url":"http://www.example.com",
            "bgcolor":"#3a3b3a",
            "color":"#fffff",
            "icon":"<i class='fa fa-music'></i>",
            //"target":"_blank",
            "title":"Join Conferance"
        },
        {
            "url":"http://www.example.com",
            "bgcolor":"#3b3b3b",
            "color":"white",
            "icon":"<i class='fa fa-music'></i>",
            "title":"Schedule Conferance"
        },
        {
            "url":"http://www.example.com",
            "bgcolor":"#3b3b3b",
            "color":"white",
            "icon":"<i class='fa fa-music'></i>",
            "title":"My Conferance"
        }
    ]
    $('.kc_fab_wrapper').kc_fab(links);


    
    $('.sidebar').on('click', 'li', function() {
        $('.sidebar li.active').removeClass('active');
        $(this).addClass('active');
        $('.sidebar').addClass('active');
        $('.overlay').addClass('active');
        $('.leftArrow').css({"display": "block"});
        $('.rightNav').css({"z-index":"998"});
    });

    $('.overlay, .leftArrow, .rightArrow').on('click', function () {
        $('.sidebar').removeClass('active');
        $('.overlay').removeClass('active');
        $('.overlay').css({"z-index":"998"});
        $('.sidebar, .rightNav').css({"z-index":"1000"});

        $('.leftArrow').css({"display": "none"});
        $('.rightArrow').css({"display": "none"});

        $('.rightNav').css({"width":"64px"});
        $('.rightTitle').removeClass('active');
        $('.rightNav ul .inner').css({"display": "none"});
        $('.toggle').next().removeClass('show');
    });

    $('.rightNav ul li').on('click', function(){
        $('.rightNav').css({"width":"250px"});
        $('.rightTitle').addClass('active');
        $('.sidebar').css({"z-index":"998"});
        $('.overlay').css({"z-index":"999"});
        $('.overlay').addClass('active');
        $('.rightArrow').css({"display": "block"});
    });


    $('.toggle').click(function(e) {
        e.preventDefault();
    
      var $this = $(this);
    
      if ($this.next().hasClass('show')) {
          $this.next().removeClass('show');
          $this.next().slideUp(350);
      } else {
          $this.parent().parent().find('li .inner').removeClass('show');
          $this.parent().parent().find('li .inner').slideUp(350);
          $this.next().toggleClass('show');
          $this.next().slideToggle(350);
      }
  });


  $('.form-group input').focus(function(){
    me = $(this) ;
    $("label[for='"+me.attr('id')+"']").addClass("animate-label");
  }) ;
  $('.form-group input').blur(function(){
    me = $(this) ;
    if ( me.val() == ""){
      $("label[for='"+me.attr('id')+"']").removeClass("animate-label");
    }
  }) ;


  $(".loginForm").on('click', '.broadCastBtn', function(){
      $(".loginForm").css("background", "#00a17c");
      $(".formTitle").html("Broadcast");
      $(".formTitle, .form-group label, .custBtn").css("color", "#fff");
      $(".form-control").css("border-bottom","1px solid #fff");
      $(".custBtn").css("border", "1px solid #fff");
      $(".custBtn").css("margin-top", "108px");
      $(".joinConfBtn").show();
      $(".broadCastBtn").hide();
      $("#joinConfForm .form-group").last().hide();
  });

});

function hideSideNavs(){
    $("#leftSection").animate({left: '-80px'});
    $("#rightSection").animate({right: '-80px'});
    $("#centerSection").animate({width: '95%'});
    $(".myVideoBtn, .myVideoContainer, .closeVideo").hide();
}

function showSideNavs(){
    $(".mainContent").css({"margin-top": '0px', "transition": "all 20s;"});
    $("#leftSection").animate({left: '0px', top: '27px'});
    $("#rightSection").animate({right: '0px', top: '27px', height: '90%'});
    $("#centerSection").animate({width: '86%', height: '90%'});
    $("#headerSection").slideUp("slow");
    $(".myVideoBtn, .myVideoContainer, .closeVideo").hide();
}

function expandVideo(){
    $("#leftSection").animate({left: '-80px'});
    $("#rightSection").animate({right: '-80px'});
    $("#centerSection").animate({width: '95%'});
    $(".cloudHeader").css("box-shadow","none");
    $(".navbar-brand, .userDetails").hide();
    $(".fullScreenClose").show();
    $(".myVideoBtn").show();
}

function showMyVideo(){
    $(".myVideoBtn").hide();
    $(".myVideoContainer").show();
    $(".closeVideo").show();
}

function closeMyVideo(){
    $(".myVideoBtn").show();
    $(".myVideoContainer").hide();
    $(".closeVideo").hide();
}


function restoreLayout(){
    $(".mainContent").css({"margin-top": '7%', "transition": "all 20s;"});
    $("#leftSection").animate({left: '0px', top: '122px'});
    $("#rightSection").animate({right: '0px', top: '122px', height: '80%'});
    $("#centerSection").animate({width: '86%', height: '80%'});
    $("#headerSection").slideDown("slow");
    $(".cloudHeader").css("box-shadow","1px 1px 1px #ccc");
    $(".fullScreenClose").hide();
    $(".navbar-brand, .userDetails").show();
}
