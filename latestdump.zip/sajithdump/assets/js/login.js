$(document).ready(function(){
    var links = [
        {
            "bgcolor":"#00a17c",
            "icon":"+"
        },
        {
            "url":"http://www.example.com",
            "bgcolor":"#3a3b3a",
            "color":"#fffff",
            "icon":"<i class='fa fa-music'></i>",
            //"target":"_blank",
            "title":"Join Conferance"
        },
        {
            "url":"http://www.example.com",
            "bgcolor":"#3b3b3b",
            "color":"white",
            "icon":"<i class='fa fa-music'></i>",
            "title":"Schedule Conferance"
        },
        {
            "url":"http://www.example.com",
            "bgcolor":"#3b3b3b",
            "color":"white",
            "icon":"<i class='fa fa-music'></i>",
            "title":"My Conferance"
        }
    ]
    $('.kc_fab_wrapper').kc_fab(links);
});